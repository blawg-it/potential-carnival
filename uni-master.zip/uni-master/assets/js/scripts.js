// A $( document ).ready() block.
$(document).ready(function() {});
